import random
class Contestant:
    def __init__(self, name="", score=0):   
        self._name = name                       #생성자를 이용하여 filed를 초기화
        self._score = score

    def getName(self):
        return self._name                       #name을 return

    def getScore(self):
        return self._score                      #score를 return

    def setScore(self,value):
        self._score = value                     #score를 value 값으로 바꿈

class Human(Contestant):
    def makeChoice(self):
        choice = input(self._name +", enter your choice: ") #사용자의 선택을 입력받음
        
        #사용자의 입력이 rock, scissors, paper가 아니면 계속 반복
        while choice != 'rock' and choice != 'scissors' and choice != 'paper' :
            print("invalid choice " + choice)                   #오류 메세지 출력
            choice = input(self._name +", enter your choice: ") #다시 입력받음
        
        return choice           #입력받은 choice를 return

class Computer(Contestant):
    def makeChoice(self):
        choice = random.randint(1,3)    #1에서 3까지 랜덤한 수 생성
        
        if choice == 1:         #1일경우
            choice = 'rock'     #computer의 선택이 rock이 됨
        elif choice == 2:       #2일경우
            choice = 'scissors' #computer의 선택이 scissors가 됨
        elif choice == 3:       #3일경우
            choice = 'paper'    #computer의 선택이 paper가 됨

        return choice           #computer의 랜덤 choice return
