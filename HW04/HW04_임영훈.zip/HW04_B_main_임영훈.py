from HW04_B_classes_임영훈 import *

def main():
    humanName = input("Enter name of human: ")          #human의 이름을 입력받음
    computerName = input("Enter name of computer: ")    #computer의 이름을 입력받음

    human = Human(humanName)                            #Human object를 만든다
    computer = Computer(computerName)                   #Computer object를 만든다

    for i in range(3):                                  #3번 반복한다
        playGame(human, computer)                       #가위바위보 한판을 한다
        #가위바위보 결과를 출력
        print("{}: {}, {}: {}".format(human.getName(), human.getScore(), computer.getName(), computer.getScore()))
    
    if human.getScore() == computer.getScore():         #점수가 같으면 TIE 출력
        print("TIE")
    elif human.getScore() > computer.getScore():        #human의 점수가 더 높으면
        print(human.getName() + " WIN")                 #human이 이겼다고 출력
    else:                                               #computer의 점수가 더 높으면
        print(computer.getName() + " WIN")              #computer가 이겼다고 출력
 
def playGame(h, c):
    choiceH = h.makeChoice()
    choiceC = c.makeChoice()


    if choiceH == choiceC:
        pass
    elif judge(choiceH, choiceC):
        h.setScore(h.getScore() + 1)
    else:
        c.setScore(c.getScore() + 1)

def judge(choiceH, choiceC):
    if ((choiceH == 'rock' and choiceC == 'scissors') or
        (choiceH == 'paper' and choiceC == 'rock') or
        (choiceH == 'scissors' and choiceC == 'paper')):
        return True
    else:
        return False
    
main()
