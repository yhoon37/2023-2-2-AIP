from HW04_A_classes_임영훈 import *

def main():
    numerator = eval(input('Enter the Numerator: '))
    denominator = eval(input('Enter the Denominator: '))

    fraction = Fraction(numerator, denominator)
    fraction.print()
    
    reduced_fraction = IrreducibleFraction(numerator, denominator)
    reduced_fraction.print()

main()