class Fraction():
    def __init__(self, numerator=0, denominator=1):
        self._numerator = numerator             #생성자를 이용해 filed를 초기화 해준다
        self._denominator = denominator

    def getNumerator(self):
        return self._numerator                  #numerator return
 
    def setNumerator(self, value):              
        self._numerator = value                 #numerator를 value 값으로 바꾼다
 
    def getDenominator(self):                   
        return self._denominator                #denominator return

    def setDenominator(self, value):            
        self._denominator = value               #denominator를 value 값을 바꾼다
 
    def print(self):                            #원하는 형식으로 출력
        print("The fraction is {}/{}".format(self._numerator, self._denominator))

class IrreducibleFraction(Fraction):
    def __init__(self, numerator=0, denominator=1):
        #super()을 이용하여 numerator와 denominator를 초기화 한다
        super().__init__(numerator, denominator)   
        gcd = self._GCD(numerator, denominator)     #두 수의 GCD를 구한다
        self._numerator /= gcd                      #gcd로 나눈수를 저장한다
        self._denominator /= gcd                    #gcd로 나눈수를 저장한다
 
    def _GCD(self, m, n):
        #유클리드 알고리즘을 이용하여 최대 공약수를 구하여 m에 저장한다
        if (n>m):
            temp = n
            n = m
            m = temp

        while (n > 0):
            m,n = n, m%n    #-------------유클리드 알고리즘-----------------

        return m    #GCD return
      
    def print(self):        #출력 형식에 맞게 출력한다
        print("The reduced fraction is {0:.0f}/{1:.0f}".format(self._numerator, self._denominator))
